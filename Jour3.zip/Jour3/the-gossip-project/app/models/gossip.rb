class Gossip < ApplicationRecord
end
